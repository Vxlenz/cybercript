window.CYBERCRIPT_FIREBASE = {apiKey:'', projectId:''};
